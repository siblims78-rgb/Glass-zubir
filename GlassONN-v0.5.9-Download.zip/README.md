# Glass ONN v0.5.9 — Cinematic Scroll + Trakt (Personal Beta)

**Incremental update from v0.5.8.** This remains a normal Android TV app. It does not replace the stock Sony/ONN launcher and does not require Accessibility, root, or overlay permissions.

## New and corrected features

- **Vertical scrolling on Home**: separate, full-size Trending Movie and Trending TV shelves; lower rows are no longer clipped by layout presets.
- **Real catalog search**: Search from the rail opens Cinemeta search for movies and TV, with status/fallback if internet is unavailable. Add-ons installed privately in Stremio are not readable by another app.
- **Next Play D-pad**: focus moves from a selected title to Next Play, then to Play. Home Next Play shelf appears after you add a title.
- **Gentler weather ambience**: Clear and Cloud wind levels reduced; the previously selected rain resource is preserved. Individual sound tests stay in Settings.
- **Glass UI default**: 50% opacity, 0px blur on fresh installation. Existing saved preferences override defaults.
- **Prayer UI**: mosque icon, bold names, and a countdown in hours/minutes/seconds to the next prayer in today's verified response. After Isha the app labels tomorrow's time as unverified rather than inventing a countdown.
- **Optional Trakt Continue Watching**: user-authorized, read-only playback data from Trakt is shown in its own shelf with title, episode (if returned), and progress percentage. No invented progress and no account data if you don't connect.
- **Next Play stays separate**: manual Glass ONN queue is not claimed to be Stremio account progress.

## Build

1. Upload `GlassONN-v0.5.9-Download.zip` to your GitHub repository.
2. In your existing `.github/workflows/build-from-zip.yml`, change the extraction command to:

   `unzip -o -q GlassONN-v0.5.9-Download.zip`

3. Commit the workflow change and open GitHub Actions -> newest successful run -> Artifacts -> `GlassONN-debug-apk`.
4. Extract `app-debug.apk` from the artifact and install it only as a test app; keep Sony Home/Projectivy as fallback and never bypass Play Protect.

Alternative included workflow `.github/workflows/build.yml` can select the newest archive, but your existing remote workflow won't change unless you explicitly replace it.

## Trakt setup (optional, **personal TV use only**)

1. Trakt supports OAuth Device Code for TV devices, but Glass ONN needs a *separate* authorized connection from the one already used in Stremio.
2. Visit https://developer.trakt.tv/apps and register **your own** Trakt API application using your verified GitHub developer account. Keep your application's Client ID and Client Secret private. Do not post either in public GitHub issues, ZIP source, screenshots, or ChatGPT messages.
3. On the TV, open Glass ONN -> **Tetapan -> Trakt** and enter the Client ID and Client Secret **on the TV**. Press **Sambung Trakt**. Do **not** put those credentials into the HTTP phone Companion.
4. Follow the code and verification URL shown on the TV, opening Trakt on your phone and approving the authorization there. Glass ONN never asks for your Trakt account password.
5. When connected, the app asks the documented authenticated Trakt `/sync/playback` endpoint. Actual progress appears only if the API grants access and the Stremio scrobbler has sent suitable progress data. Tap a title to open its detail in Stremio; exact resume is handled by Stremio.
6. **Putuskan sambungan** deletes the local encrypted credentials and token. To revoke the authorization server-side, also remove the application's grant from your Trakt account settings.

### Important Trakt limits

- OAuth device flow is a beta personal workflow. The app reads a **user-entered personal API app Client Secret**, encrypting it with Android Keystore locally; nothing is baked into this public source ZIP. For any public/multi-user distribution, move to Trakt's recommended PKCE with a verified HTTPS Android App Link and a proper identity deployment. Do not distribute a shared Client Secret in the APK.
- Trakt may require additional access for certain endpoints, or return 402/403/429. The launcher reports that instead of faking watch history. It caches UI state locally for the open session and makes bounded network requests.
- Stremio's internal Continue Watching shelf is not the same as Trakt's playback history. Netflix doesn't offer an approved public account API for an external launcher to read its Continue Watching list.
- This integration requests read-only progress. It does not synchronize or update what you've watched. It never scrapes your Stremio or Netflix private account.
- **Glass ONN uses Trakt but is not endorsed or certified by Trakt.**

## Testing status

- JavaScript syntax and Java parsing checked locally, including all existing Java sources.
- Browser/UI tested with sample data at 1280×720, 1920×1080 and 1280×600; Home scroll, Next Play focus and Trakt rendering passed.
- Android APK **has not yet been compiled** from v0.5.9 source, and real Trakt OAuth/device playback **has not yet been tested on the user's TV**.

## Data handling

- Local app preferences use private app storage. Trakt OAuth/app credentials are encrypted using a non-exportable Android Keystore AES-GCM key. The app does **not** send credentials or tokens to the HTTP Companion or print them in logs.
- Phone Companion remains LAN-only HTTP for non-account settings; use a trusted home network. Avoid exposing its port to the internet.
- External metadata/artwork requires internet and may be unavailable. Prayer times are for reference and should be checked against e-Solat JAKIM.
