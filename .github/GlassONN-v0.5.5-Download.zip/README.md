# Glass ONN v0.5.5 — Cinematic Refinement (incremental update)

Based directly on the **v0.5.4 codebase**, retaining MainActivity, CompanionServer, WebView, existing cards, native app banners, Cinemeta, TMDB opt-in, weather, prayers, preferences and app shortcuts.

Changes:
- Dark Cinematic UI with subtler glass borders and smoother lightweight focus states; no new runtime libraries.
- Remote-accessible widget sizing: Info/Prayer, Movie, Apps each adjustable -3..+3 steps. A fixed total vertical height redistributes space to reduce overlap. Existing Movie/Apps/Compact presets still work.
- Reposition prayer & clock panels left/right; reorder Movie and Apps with existing remote toggle. This is **not** free dragging.
- Slightly larger cinematic recommendation artwork; app focus halo on the actual original banner/icon, not the outer card.
- A small, clearly labelled **Baru dibuka dari Glass ONN** recent-title subset. This is launcher navigation history; **not** a Stremio Continue Watching progress sync. The app does not access Stremio watch history or personal addon configuration.
- Companion settings for panel swap and individual size controls, backed by existing paired LAN interface and local Android preferences.

Privacy and limitations: Cinemeta is a public Stremio catalog, not the user's private TMDB addons. TMDB requires user-provided token and is optional. Media links are metadata/search deep links, not playback guarantees. Continue Watching would require a separate user-authorized sync. Weather and film images are downloaded from external providers as before; not bundled. Test as a regular app; keep Sony Home / Projectivy as backup, leave Play Protect enabled.

Build: Gradle 8.9, Java 17, Android SDK 34, `gradle :app:assembleDebug`. No new permissions or dependencies.
