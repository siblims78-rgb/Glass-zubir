# Glass ONN v0.5.3 — Compact TV UI, icon glow, smart weather sounds

## Changes from v0.5.2
- Compact clock/weather/prayer panels (~25vh instead of ~34vh); larger horizontal movie recommendation strip (up to 36vh) with enlarged posters. Fits 1280x600, 1280x720 and 1920x1080 screens.
- App banners remain 16:9 but the *artwork itself* receives focus glow. Card frame never glows. Glow is color-matched for common TV apps (Netflix/YouTube red, Stremio purple, Astro magenta) and estimated from icon artwork for others when possible.
- Weather sound is OFF by default. When enabled, plays at FIRST successful weather update after opening launcher, and once on a subsequent weather category change (with a 60s cooldown). Periodic animation is SILENT. Sun/Cloud use soft wind ambience; Rain uses rain; Storm thunder follows visual lightning. Explicit FX test also plays sound if enabled.
- Movie browser has larger list thumbnails and an uncropped 2:3 poster in details. Scroll list with remote, select for details, separate Play for opening an app.
- All Apps, Hide Apps, long OK, Display Cards, Companion and weather visuals retained.

## Important
- This is an experimental TV app, not a HOME replacement. Projectivy/Sony Home remain unchanged. No special access, no Accessibility, no GPS. Keep Play Protect enabled.
- Source/UI updated; on-device testing and GitHub Android build required.
- Optional weather audio is generated, low volume and one-shot. It stops on leaving the app. Mute or turn OFF when not wanted.
- Streaming availability is not guaranteed. TMDB token is optional, Netflix search is fallback, Stremio may not deep link to title on some versions.
- LAN phone companion uses unencrypted HTTP and pairing: only on trusted local networks.
- Offline artwork and online wallpaper fallbacks remain.
- This package has app ID com.glassonn.home.v053 and installs alongside v0.5.2; preferences will not migrate automatically.
