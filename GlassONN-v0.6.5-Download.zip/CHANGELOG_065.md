# Glass ONN v0.6.5 — Companion & TV fixes

## User feedback addressed

1. New Companion mobile navigation (Wallpapers / Widgets / Apps / Appearance / Services), consistent cards and type hierarchy, compact accessible touch targets.
2. Implemented missing `showUserWallpaper()` in TV Home JS, loading selected private-cache JPEG via WebView intercepted `glassonn.local` resource request. Companion now distinguishes upload success from a TV image-load success/error. Fixed and shuffle modes persist locally.
3. Restored storm thunder sample as a separate bundled public-domain field recording; no fake synthesized thunder.
4. Distinct clear (birds), cloudy (gentle breeze), rain, storm (rain with thunder) ambient recordings; bundled into APK during Gradle build.
5. Companion touch drag-to-reorder **Apps vs Trending shelves**; drag dedicated handles to resize Clock/Prayer, Apps, Trending blocks. Cards can be enabled/disabled individually. This is a constrained layout editor, not arbitrary 2D positioning of each nested clock/weather label.
6. Home theme picker Glass / Bright / Dark. Theme saved on TV, including Companion control.
7. Trakt Live Trending Movies and Shows via official public endpoints using the user-provided on-TV Trakt Client ID, fallback to previous catalog when unavailable. Scrobble/progress and live trending are separate features; title artwork can be incomplete when external metadata is missing.

## Build and testing

- Source archive: `GlassONN-v0.6.5-Download.zip`. It contains `settings.gradle` at ZIP root.
- GitHub workflow `.github/workflows/build-from-zip.yml` currently extracts an older filename. Update its `unzip -o -q ...` line to `unzip -o -q GlassONN-v0.6.5-Download.zip` when uploading this ZIP, and commit both changes.
- Browser smoke test: Chromium with mocked Companion pairing/state, 5 tabs, upload/Fixed/Shuffle/delete/clear, toggles, touch editor; JS syntax checked. Hardware tests and Android APK build still pending.
- Gradle build downloads authentic audio WAV? No, OGG, from Wikimedia Commons as `app/src/main/assets/nature/*.ogg`; if files cannot be fetched the Android build fails clearly.
- v0.6.5 has separate Android `applicationId` to preserve v0.6.4 side by side. Login pairing/configuration does NOT transfer automatically.
- Local Companion HTTP is unencrypted: use trusted home Wi-Fi only; no cloud for user gallery. Photos stored in Android private cache, subject to OS cleanup.
