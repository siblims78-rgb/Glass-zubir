# v0.6.5 authentic weather ambience — sources and rights

These four original field recordings are fetched by the GitHub Android build from Wikimedia Commons and packaged in APK assets. The source repository ZIP contains references only, not embedded audio files. Gradle checks HTTP status, a 5 KB minimum, and the OggS file signature; missing audio causes build failure instead of a silently muted launcher.

All four audio recordings are public domain as indicated by their respective Commons pages; the source audio is not synthesized and is not uploaded to a cloud service by Glass ONN.

- **Clear (garden bird song):** `Birds singing in garden.ogg`, ezwa, 2007. https://commons.wikimedia.org/wiki/File:Birds_singing_in_garden.ogg — https://upload.wikimedia.org/wikipedia/commons/8/80/Birds_singing_in_garden.ogg
- **Cloudy (gentle breeze with birds):** `Gentle breeze and birds singing.ogg`, ezwa, 2007. https://commons.wikimedia.org/wiki/File:Gentle_breeze_and_birds_singing.ogg — https://upload.wikimedia.org/wikipedia/commons/0/0e/Gentle_breeze_and_birds_singing.ogg
- **Rain (natural rain recording):** `Rain.ogg`, ジダネ, 2007. https://commons.wikimedia.org/wiki/File:Rain.ogg — https://upload.wikimedia.org/wikipedia/commons/3/3d/Rain.ogg
- **Storm (rain and thunder recording):** `Rain and thunder.ogg`, User:Caesar, 2006. https://commons.wikimedia.org/wiki/File:Rain_and_thunder.ogg — https://upload.wikimedia.org/wikipedia/commons/4/42/Rain_and_thunder.ogg

Only a short low-volume portion plays at weather start/change. It is not a continuously looping soundscape. Listening level varies by TV/receiver; check for surprises during testing, particularly the storm recording.
