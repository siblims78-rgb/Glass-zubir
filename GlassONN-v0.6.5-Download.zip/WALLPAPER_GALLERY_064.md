# Glass ONN v0.6.4 — Personal Wallpaper Gallery

## End-to-end flow
1. On the TV: Settings > Integrations > Phone Companion. Scan QR, enter PIN.
2. On the phone: Personal Wallpaper Gallery > choose images (single or multiple). Browser downsizes images to no more than 1920px in either dimension and converts to JPEG, stripping camera metadata.
3. POST /wallpaper/upload uploads only to the TV's paired local Companion server on TCP 8765 (HTTPS/cloud not used). Authentication uses the temporary X-Glass-Token pairing token.
4. The server validates JPEG payload and dimensions and saves within Context.getCacheDir()/glassonn_user_wallpapers. Images are loaded on the TV through WebViewClient.shouldInterceptRequest on a pseudo-HTTPS internal image URL. No public image server, cloud storage, Android photo permission, or media scans.
5. Mode: Fixed shows the selected photo; Shuffle picks a random image avoiding immediate repeats every 30 seconds while on Home.
6. Companion supports gallery thumbnails, select Fixed, Shuffle, remove one, clear all.

## Limits and cleanup
- Max 24 files, max 2.5MB each after client compression, 32MB total.
- Image dimensions between 240px and 4096px per side, maximum 12MP.
- Android may automatically evict cached images to reclaim space. Clearing app cache removes user wallpaper files.
- If image is unavailable, launcher displays its bundled offline background instead.
- The user can return to original cinematic or offline wallpapers at any point.

## Security caveat
Local HTTP is not TLS-encrypted. Intended only on trusted home LAN. Never use the Companion on public/hotel Wi-Fi. Images and session token traverse that local network. No upload to GitHub or a remote image host.

## Tests still needed
On a physical ONN device test companion QR/pairing, bulk upload of 2–5 images, fixed image persistence, shuffle with no adjacent repeats, navigation focus, delete/clear, cache eviction, and installation. CI build hasn't been run for this source.
