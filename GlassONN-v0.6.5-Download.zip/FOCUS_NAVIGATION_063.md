# Settings D-pad focus fix — v0.6.3

All settings categories now keep D-pad focus in the active right-hand panel after a selection, including re-rendered buttons. The active category remembers the last focused control. Vertical arrow navigation never jumps into the left navigation. From the sidebar, RIGHT opens the focused control for the chosen tab. LEFT from the left edge of the settings panel returns to sidebar; BACK within content returns to the sidebar, and BACK from sidebar exits Settings.

Validated in headless Chromium: Appearance clock change; Home visibility (Favorite Apps) after OK; 6x ArrowDown on Home, Weather and Integrations; switch tabs; BACK twice. No runtime page errors in this browser smoke test. Not yet tested on ONN/Sony hardware.
