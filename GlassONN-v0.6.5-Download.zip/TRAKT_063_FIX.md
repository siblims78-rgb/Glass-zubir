# Glass ONN v0.6.3 — Trakt Client ID–only login fix

Official Trakt documentation now provides a Client ID for new apps but not necessarily a Client Secret. The v0.6.2 launcher incorrectly required both. This update:

- Removes Client Secret input from TV Settings.
- Requests OAuth device code and polls device token with Client ID only.
- Refreshes access tokens using Client ID and refresh token, without Client Secret or a mismatched redirect URI.
- Retains encrypted token storage via Android Keystore and D-pad settings controls.
- Shows HTTP status from failed code issuance so errors can be diagnosed.
- Uses separate test application ID `com.glassonn.home.v063`. Old v0.6.2 remains installed; users must re-enter their personal Client ID into the new app.

## Build via GitHub (same workflow)

Upload the **compatibility-named** `GlassONN-v0.6.2-Download.zip` and replace the existing file of the same name in the repository. The repository's workflow currently extracts that filename. Its contents will build v0.6.3. `GlassONN-v0.6.3-Download.zip` is an identically packaged, correctly named archive for future use when the workflow is updated.

The fix is statically checked; actual device OAuth must be tested on a TV. Never share your Trakt access token in screenshots or chat.

## v0.6.3 Zen audio and Companion QR

- Fixed playback race where asynchronous stop killed the just-started MediaPlayer.
- Real nature audio files are bundled at build time; build fails if Wikimedia recordings could not be retrieved, avoiding silent APKs. Offline playback works without first-run Internet.
- Added on-TV QR using MIT-licensed QRCode JavaScript, bundled locally; QR points to live local `http://TV-IP:8765` only, without pairing PIN/token in the QR payload. Enter the TV's pairing PIN after scanning. Same trusted home Wi-Fi required.
- Existing HTTP Companion pairing remains PIN-protected; do not enter Trakt/TMDB secrets into Companion.
