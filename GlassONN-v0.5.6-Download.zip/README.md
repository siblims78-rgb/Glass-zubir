# Glass ONN v0.5.6 — Cinematic Focus (incremental)

Based on v0.5.5. Keeps the original MainActivity, CompanionServer, permissions, remote logic, app discovery, prayers, weather, Cinemeta and optional TMDB.

Changes:
- Large cinematic Home recommendation artwork and larger posters in the browse list/details.
- Focus-based wallpaper preview from Stremio/TMDB `background`, with poster fallback when no backdrop exists. The overlay restores the prior wallpaper after focus leaves movie cards or closes Browse. Only HTTPS artwork URLs are used.
- Android TV app banners preserved. App titles are OFF by default, with a toggle in TV settings. App names remain available as accessibility labels.
- Apps-first arrangement by default for new installs, matching the supplied reference. Existing saved layout choices are respected.
- Sound refinement: asynchronously cache the **public-domain field recording `Rain.ogg`**; fallback short offline rain/leaf-rustle ambience generated for offline playback. Weather sound uses normal startup/change triggers, not repeating idle animation sound.

### Audio sourcing
- Real rain recording: Wikimedia Commons [Rain.ogg](https://commons.wikimedia.org/wiki/File:Rain.ogg), 2007, author ジダネ, **public domain** (original unmodified recording; local cached copy). Direct source: https://upload.wikimedia.org/wikipedia/commons/3/3d/Rain.ogg
- Offline fallback rain and leaf-rustle ambience: generated algorithmically for this version, not recordings. Do not claim the dry-leaves sound is a licensed field recording. Other existing audio retained.

The app stays an ordinary TV application, not a Home replacement. No extra dangerous permissions. GitHub: Gradle 8.9 / Java 17 / SDK 34.
