# Glass ONN v0.5.4 — experimental Sony/ONN Android TV launcher

What's new: remote-friendly Layout Editor (Balanced / Movie Focus / Apps Focus / Compact, swap Trending/Apps); live metadata catalogs from official Stremio Cinemeta (no Stremio credentials); Dark Cinematic wallpaper from backdrop metadata with local fallback; sound diagnostics, audio focus, audible sample volume; native TV banners preserve intrinsic aspect. Existing All Apps, Companion, weather, JAKIM zone, and previous playback/search paths retained.

**Limits**: Does NOT read addons installed inside user's Stremio account. Cinemeta's "Popular" is not a real-time TMDB trending ranking. Artwork displays online only, sourced from existing metadata; it isn't bundled in the ZIP. Cinematic wallpaper may fall back to offline if metadata image isn't supplied/loaded. Sound effects are ON by default in a new install; may be disabled at any time. Layout Editor offers preset size/row ordering, not fully free-form drag-and-drop.

**Safety**: test as normal app; do not replace stock Home; Play Protect remains on. Companion uses paired HTTP over trusted home Wi-Fi only, never exposed to Internet. Do not add secrets in public GitHub repositories. APK has no streaming code.

Build: `gradle :app:assembleDebug` (Android SDK 34, Java 17, Gradle 8.9). GitHub Actions workflow included.
