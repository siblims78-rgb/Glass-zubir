# Glass ONN v0.4.1 · Sony / ONN TV test

## Extra changes in v0.4.1
- Display Cards switches: Cuaca, Waktu Solat, Trending, Aplikasi Kegemaran. Stored in Android SharedPreferences and editable on TV or phone companion. Clock and All Apps remain reachable.
- Hide apps from Glass ONN All Apps without uninstalling/disabling, with “Tunjuk hidden”/restore control. Hiding an app also removes it from favourites, so it does not appear in Home.
- Existing favorites ★ choices remain limited to 8. The phone Companion supports card visibility and hidden-app restoration.

## Changes from v0.3
- Visible horizontally scrollable **Popular movies & series** strip on Home.
- Without a TMDB token: movie chart metadata from Apple's public iTunes RSS and recent-airing series from TVMaze, **not labelled TMDB trending**. With an optional TMDB token: actual TMDB weekly trending.
- Online wallpaper selection now includes Lorem Picsum/Unsplash photo service with Wikimedia Commons optional. Offline wallpapers remain fallback. Each photo source requires a reachable network and CDN; failures are shown.
- Added Home ▶ Uji FX button to demonstrate rain, clouds, sun, and gentle storm lighting; automatic weather-matched overlays after 30s idle then approx every 3min. Actual cloudy conditions now use a cloud visual rather than no animation.
- Retains All Apps, companion phone page and LAN PIN pairing.

## Known limits
- This is a **debug/test** Android TV app, NOT a system HOME launcher. Do not replace the original HOME or disable Play Protect.
- An internet connection and access to photo/CDN providers are required. If the TV blocks online services, no online poster/photo can be guaranteed. Online GIF/video support not added.
- Weather visual never runs if TV is powered off or sleeping, and clear/overcast screens do not simulate rain inaccurately.
- TVMaze shows are current TV listings, Apple movies are sales-chart titles. Only TMDB with user-supplied token is labelled trending. Poster images and source data may change or be unavailable.
- The Companion runs local HTTP, not HTTPS. Use only on trusted Wi-Fi, do not expose TCP port 8765 to Internet.
- Source tested for JS syntax and Chromium layout. Android TV runtime and APIs must still be tested.
- Gradle workflow compiles from ZIP in repository. The earlier temporary Java compile patch used in v0.3 is already integrated in source.
