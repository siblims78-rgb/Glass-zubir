package com.glassonn.home;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Glass ONN personal TV dashboard. No HOME takeover; no accessibility/overlay/GPS permissions. */
public class MainActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private WebView page;
    private CompanionServer companion;
    private final String[][] places = {
        {"Setapak / Kuala Lumpur", "WLY01", "3.205", "101.718"},
        {"Gombak / Selangor", "SGR01", "3.257", "101.702"},
        {"Kuala Lumpur", "WLY01", "3.139", "101.687"},
        {"Johor Bahru", "JHR02", "1.493", "103.742"},
        {"Pulau Pinang", "PNG01", "5.414", "100.329"}
    };
    SharedPreferences prefs() { return getPreferences(MODE_PRIVATE); }
    void sendJs(String js) { ui.post(() -> {if (page != null) page.evaluateJavascript(js, null);}); }
    void remoteUpdated() { sendJs("if(window.onRemoteChanged)window.onRemoteChanged()"); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
        page = new WebView(this);
        page.setBackgroundColor(0xff0b1429);
        page.getSettings().setJavaScriptEnabled(true);
        page.getSettings().setDomStorageEnabled(true);
        page.getSettings().setAllowFileAccess(true);
        page.getSettings().setAllowContentAccess(false);
        page.getSettings().setAllowFileAccessFromFileURLs(false);
        page.getSettings().setAllowUniversalAccessFromFileURLs(false);
        page.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                // Only the bundled HTML is permitted in the TV WebView.
                return !"file".equalsIgnoreCase(r.getUrl().getScheme());
            }
        });
        page.addJavascriptInterface(new LocalBridge(), "Native");
        setContentView(page);
        companion = new CompanionServer(this);
        page.loadUrl("file:///android_asset/index.html");
    }

    private static final String[] PRIORITIES = {
        "com.netflix.ninja", "com.stremio.one", "com.google.android.youtube.tv", "ar.tvplayer.tv",
        "com.syncler", "org.courville.nova"
    };
    private int priority(String pkg) {
        for (int i=0;i<PRIORITIES.length;i++) if (PRIORITIES[i].equals(pkg)) return i;
        return 100;
    }
    private List<ResolveInfo> discoveredApps() {
        PackageManager m=getPackageManager();
        List<ResolveInfo> out=new ArrayList<>();
        Set<String> seen=new HashSet<>();
        for(String category:new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER,Intent.CATEGORY_LAUNCHER}) {
            Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(category);
            for(ResolveInfo info:m.queryIntentActivities(i,0)) {
                if(info.activityInfo==null)continue;
                String pkg=info.activityInfo.packageName;
                if(getPackageName().equals(pkg)||!seen.add(pkg))continue;
                out.add(info);
            }
        }
        Collections.sort(out,Comparator.comparingInt((ResolveInfo x)->priority(x.activityInfo.packageName))
                .thenComparing(x->String.valueOf(x.loadLabel(m)).toLowerCase()));
        return out;
    }
    JSONArray apps(boolean withIcons) {
        JSONArray out=new JSONArray();PackageManager m=getPackageManager();
        for(ResolveInfo info:discoveredApps()){
            try{
                JSONObject j=new JSONObject();
                j.put("name",String.valueOf(info.loadLabel(m)));
                j.put("pkg",info.activityInfo.packageName);
                if(withIcons){
                    Drawable icon=info.loadIcon(m);
                    if(icon!=null){
                        Bitmap bitmap=Bitmap.createBitmap(72,72,Bitmap.Config.ARGB_8888);
                        Canvas c=new Canvas(bitmap);icon.setBounds(0,0,72,72);icon.draw(c);
                        ByteArrayOutputStream data=new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG,85,data);bitmap.recycle();
                        j.put("icon","data:image/png;base64,"+Base64.encodeToString(data.toByteArray(),Base64.NO_WRAP));
                    }
                }
                out.put(j);
            }catch(Exception ignored){}
        }
        return out;
    }
    boolean appExists(String pkg){
        if(pkg==null||pkg.length()>180||!pkg.matches("[A-Za-z0-9_.]+"))return false;
        for(ResolveInfo i:discoveredApps()) if(pkg.equals(i.activityInfo.packageName))return true;
        return false;
    }
    JSONArray favorites(){
        JSONArray stored;
        try{stored=new JSONArray(prefs().getString("favorites",""));}
        catch(Exception ex){
            stored=new JSONArray();
            for(ResolveInfo info:discoveredApps()){if(stored.length()>=8)break;stored.put(info.activityInfo.packageName);}
        }
        return stored;
    }
    boolean setFavorite(String pkg, boolean on){
        if(!appExists(pkg)||(on&&isHiddenApp(pkg)))return false;
        JSONArray old=favorites(),next=new JSONArray();boolean found=false;
        for(int i=0;i<old.length();i++){
            String v=old.optString(i);
            if(v.equals(pkg)){found=true;if(!on)continue;}
            next.put(v);
        }
        if(on&&!found){if(next.length()>=8)return false;next.put(pkg);}
        prefs().edit().putString("favorites",next.toString()).apply();
        remoteUpdated();return true;
    }
    private static final String[] CARD_NAMES={"weather","prayer","trending","favorites"};
    boolean validCard(String key){for(String name:CARD_NAMES)if(name.equals(key))return true;return false;}
    JSONObject cardState(){JSONObject out=new JSONObject();try{for(String name:CARD_NAMES)out.put(name,prefs().getBoolean("card_"+name,true));}catch(Exception ignored){}return out;}
    boolean setCardVisible(String key,boolean visible){
        if(!validCard(key))return false;
        prefs().edit().putBoolean("card_"+key,visible).apply();remoteUpdated();return true;
    }
    JSONArray hiddenApps(){try{return new JSONArray(prefs().getString("hidden_apps","[]"));}catch(Exception ignored){return new JSONArray();}}
    boolean isHiddenApp(String pkg){JSONArray hidden=hiddenApps();for(int i=0;i<hidden.length();i++)if(pkg.equals(hidden.optString(i)))return true;return false;}
    boolean setAppHidden(String pkg,boolean hidden){
        if(!appExists(pkg))return false;
        JSONArray prev=hiddenApps(),next=new JSONArray();
        for(int i=0;i<prev.length();i++){String p=prev.optString(i);if(!p.equals(pkg))next.put(p);}
        if(hidden)next.put(pkg);
        prefs().edit().putString("hidden_apps",next.toString()).apply();
        if(hidden)setFavorite(pkg,false);
        remoteUpdated();return true;
    }
    void setPlace(int n){if(n<0||n>=places.length)return;prefs().edit().putInt("place",n).apply();remoteUpdated();}
    int getPlace(){return prefs().getInt("place",0);}
    String getWallpaperMode(){return prefs().getString("wallpaper_mode","auto");}
    void setWallpaperMode(String mode){
        if(mode==null||!(mode.equals("auto")||mode.matches("[0-3]")))return;
        prefs().edit().putString("wallpaper_mode",mode).apply();remoteUpdated();
    }
    String getWallpaperSource(){return prefs().getString("wallpaper_source","picsum");}
    void setWallpaperSource(String source){
        if(!"local".equals(source)&&!"commons".equals(source)&&!"picsum".equals(source))return;
        prefs().edit().putString("wallpaper_source",source).apply();remoteUpdated();
    }
    boolean getWeatherFx(){return prefs().getBoolean("weather_fx",true);}
    void setWeatherFx(boolean state){prefs().edit().putBoolean("weather_fx",state).apply();remoteUpdated();}
    void setTmdbToken(String token){
        // This is an optional TMDB read-only API token, NOT a GitHub key or account password.
        if(token==null)return;
        token=token.trim();
        if(token.isEmpty()||token.matches("[a-zA-Z0-9_.\\-]{32,700}")) {
            prefs().edit().putString("tmdb_token",token).apply();
            remoteUpdated();
        }
    }
    boolean hasTmdbToken(){return !prefs().getString("tmdb_token","").isEmpty();}
    JSONObject companionState(){
        JSONObject j=new JSONObject();
        try{
            j.put("place",getPlace());j.put("wallpaper",getWallpaperMode());
            j.put("source",getWallpaperSource());j.put("fx",getWeatherFx());
            j.put("tmdbConnected",hasTmdbToken());j.put("cards",cardState());j.put("hidden",hiddenApps());j.put("favorites",favorites());
            j.put("apps",apps(false));
        }catch(Exception ignored){}
        return j;
    }

    private class LocalBridge {
        @JavascriptInterface public String getPlace(){return ""+MainActivity.this.getPlace();}
        @JavascriptInterface public void setPlace(String s){try{MainActivity.this.setPlace(Integer.parseInt(s));}catch(Exception ignored){}}
        @JavascriptInterface public String getWallpaperMode(){return MainActivity.this.getWallpaperMode();}
        @JavascriptInterface public void setWallpaperMode(String m){MainActivity.this.setWallpaperMode(m);}
        @JavascriptInterface public String getWallpaperSource(){return MainActivity.this.getWallpaperSource();}
        @JavascriptInterface public void setWallpaperSource(String s){MainActivity.this.setWallpaperSource(s);}
        @JavascriptInterface public boolean getWeatherFx(){return MainActivity.this.getWeatherFx();}
        @JavascriptInterface public void setWeatherFx(boolean on){MainActivity.this.setWeatherFx(on);}
        @JavascriptInterface public String getDisplayCards(){return cardState().toString();}
        @JavascriptInterface public void setCardVisible(String key, boolean visible){MainActivity.this.setCardVisible(key,visible);}
        @JavascriptInterface public String getHiddenApps(){return hiddenApps().toString();}
        @JavascriptInterface public void setAppHidden(String pkg,boolean hidden){MainActivity.this.setAppHidden(pkg,hidden);}
        @JavascriptInterface public String getFavorites(){return favorites().toString();}
        @JavascriptInterface public void setFavorite(String pkg, boolean on){MainActivity.this.setFavorite(pkg,on);}
        @JavascriptInterface public String getApps(){return apps(true).toString();}
        @JavascriptInterface public String getCompanionInfo(){
            JSONObject j=new JSONObject();
            try{
                j.put("url",companion==null?"":companion.address());
                j.put("pin",companion==null?"":companion.pin());
                j.put("online",companion!=null&&companion.running());
            }catch(Exception ignored){}
            return j.toString();
        }
        @JavascriptInterface public boolean hasTmdb(){return hasTmdbToken();}
        @JavascriptInterface public void openApp(String pkg){
            if(!appExists(pkg))return;
            ui.post(()->{
                Intent i=getPackageManager().getLeanbackLaunchIntentForPackage(pkg);
                if(i==null)i=getPackageManager().getLaunchIntentForPackage(pkg);
                if(i!=null){try{startActivity(i);}catch(Exception ignored){}}
                else Toast.makeText(MainActivity.this,"App tidak boleh dibuka",Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void fetch(String kind){
            if(!"weather".equals(kind)&&!"prayer".equals(kind)&&!"gallery".equals(kind)&&!"trending".equals(kind)&&!"popularMovies".equals(kind)&&!"popularShows".equals(kind))return;
            new Thread(()->{
                HttpURLConnection conn=null;
                try{
                    String url;
                    if("weather".equals(kind)){
                        String[] p=places[MainActivity.this.getPlace()];
                        url="https://api.open-meteo.com/v1/forecast?latitude="+p[2]+"&longitude="+p[3]+
                            "&current=temperature_2m,relative_humidity_2m,weather_code,is_day&timezone=Asia%2FKuala_Lumpur";
                    }else if("prayer".equals(kind)){
                        url="https://solat.my/api/daily/"+places[MainActivity.this.getPlace()][1];
                    }else if("popularMovies".equals(kind)){
                        url="https://itunes.apple.com/us/rss/topmovies/limit=20/json";
                    }else if("popularShows".equals(kind)){
                        url="https://api.tvmaze.com/schedule?country=US";
                    }else if("gallery".equals(kind)){
                        url="https://commons.wikimedia.org/w/api.php?action=query&generator=categorymembers"+
                          "&gcmtitle=Category%3AFeatured_pictures_of_landscapes&gcmtype=file&gcmlimit=25"+
                          "&prop=imageinfo&iiprop=url%7Csize%7Cextmetadata&iiurlwidth=1600&format=json";
                    }else{
                        if(!hasTmdbToken()){sendJs("window.onNativeData('trending','')");return;}
                        url="https://api.themoviedb.org/3/trending/all/week?language=en-US&page=1";
                    }
                    conn=(HttpURLConnection)new URL(url).openConnection();
                    conn.setConnectTimeout(9000);conn.setReadTimeout(10000);
                    conn.setRequestProperty("User-Agent","GlassONN/0.4 (https://github.com/siblims78-rgb/Glass-zubir) AndroidTV");
                    if("trending".equals(kind)){
                        String token=prefs().getString("tmdb_token","");
                        if(token.length()==32){ // legacy TMDB v3 API key, not a Bearer token
                            conn.disconnect();conn=(HttpURLConnection)new URL(url+"&api_key="+token).openConnection();
                            conn.setConnectTimeout(9000);conn.setReadTimeout(10000);
                        }else conn.setRequestProperty("Authorization","Bearer "+token);
                    }
                    if(conn.getResponseCode()!=200)throw new Exception("API HTTP "+conn.getResponseCode());
                    ByteArrayOutputStream out=new ByteArrayOutputStream();
                    int max="gallery".equals(kind)?1_200_000:("popularShows".equals(kind)?2_000_000:900_000);
                    try(InputStream in=new BufferedInputStream(conn.getInputStream())){
                        byte[] buffer=new byte[8192];int count;
                        while((count=in.read(buffer))!=-1){
                            if(out.size()+count>max)throw new Exception("Too much data");
                            out.write(buffer,0,count);
                        }
                    }
                    sendJs("window.onNativeData("+JSONObject.quote(kind)+","+JSONObject.quote(out.toString("UTF-8"))+")");
                }catch(Exception ex){sendJs("window.onNativeData("+JSONObject.quote(kind)+",'')");}
                finally{if(conn!=null)conn.disconnect();}
            },"GlassONN-API-"+kind).start();
        }
    }

    @Override protected void onResume(){
        super.onResume();
        if(companion==null||!companion.running()){
            companion=new CompanionServer(this);
            companion.start();
        }
        remoteUpdated();
    }
    @Override protected void onPause(){
        // Paired LAN control is only reachable while Glass ONN is the foreground app.
        if(companion!=null)companion.stop();
        super.onPause();
    }
    @Override public void onBackPressed(){sendJs("if(window.handleBack)window.handleBack()");}
    @Override protected void onDestroy(){
        if(companion!=null)companion.stop();
        if(page!=null){page.removeJavascriptInterface("Native");page.destroy();page=null;}
        super.onDestroy();
    }
}
