# Glass ONN — Home dashboard Android TV (source project)

**Status:** Source code / prototype 0.1.0 (static HTML/manifest validation passed; Android build pending). **APK has not been built or tested on a physical ONN device in this environment.** This is **not** the previously blocked `glass-tv-home.apk`, and is **not** affiliated with cocombee or any third-party APK seller.

## Design
- Glassmorphism is a **real translucent panel with CSS `backdrop-filter` blur**, rather than a blur filter baked into the wallpaper.
- Rotates four abstract navy/aurora wallpapers automatically every 30 seconds. Glass effect remains on top when wallpaper changes.
- Optional user-selected wallpaper through Android file picker (no storage permission). Images are resized/compressed on the device.
- Large MYT clock, date, Open-Meteo current weather, Malaysia prayer times via solat.my (which cites JAKIM).
- TV apps are discovered locally using `LEANBACK_LAUNCHER` and `LAUNCHER` intents. Remote directional keys navigate apps and settings.
- Optimized for landscape, Android TV 14 and approximately 2 GB RAM; lightweight WebView UI, no external UI libraries.

## Privacy/safety
- Permissions: **INTERNET only**.
- **No** Accessibility, Notification Listener, GPS, install-other-packages, overlay, microphone, camera, contacts or account permissions.
- Never asks for Google login or API keys.
- HTTPS requests go only to `api.open-meteo.com` and `solat.my`.
- Not a security audit, and no guarantee about Play Protect decisions. Do **not** disable Play Protect if installation is blocked.
- Home override is **not** enabled in manifest. Install and launch it as a normal app first. Keep Projectivy as Home/backup.

## Build (Android Studio / cloud GitHub Actions)
1. Create a private GitHub repository initialized with README, then upload these source files (or let ChatGPT copy them using a connected GitHub integration once the repo is available).
2. GitHub Actions builds using `ubuntu-latest`, Java 17, Gradle 8.9, Android SDK 34, Android Gradle Plugin 8.6.1.
3. Open `Actions` → `Build Glass ONN APK` → `Run workflow`, or push to the `main` branch.
4. On a successful run, download the **GlassONN-debug-apk** artifact; unzip to get `app-debug.apk`.
5. Transfer to ONN using Send Files to TV and install as a **test app only**. If Play Protect blocks, do not bypass it.

## Phone-only method (GitHub Codespaces)
1. On Chrome (Desktop site may be needed), sign in to GitHub and create a **private** empty repository.
2. Open its `Code` → `Codespaces` → `Create codespace on main` (where your plan supports Codespaces).
3. Upload this ZIP into the Codespaces file explorer (the file can be called `GlassONN-source.zip`).
4. In Codespaces terminal, run:
   ```sh
   unzip -o GlassONN-source.zip
   git add . && git commit -m "Add Glass ONN project" && git push
   ```
5. In GitHub `Actions`, open the build run, download the artifact once green and extract the APK.

This workflow uses GitHub-hosted build tools. It is offered as a way to build from inspectable source code, not a claim that the APK has already been created.

## Customization
- `app/src/main/assets/index.html` controls the UI, appearance and app dock.
- `app/src/main/java/com/glassonn/home/MainActivity.java` contains the Android activity, app detection and fixed allowlisted weather/solat HTTPS requests.
- Location settings include Selangor/Petaling (SGR01), Kuala Lumpur (WLY01), Johor Bahru (JHR02), Pulau Pinang (PNG01). **Select the correct zone yourself**; do not rely on the default if you are elsewhere.
- Project could be adapted to a Home app later by adding `HOME`+`DEFAULT` intent filters, but **not recommended before testing**.

## Known limitations
- Unbuilt, untested prototype: Android version, WebView version, remote handling and API schemas may require refinement.
- Actual weather and prayer require internet; third-party API uptime may affect them.
- No login or real-time app recommendations. The cards row displays the first 8 installed apps ranked by favorites.
- This is not a replacement for Projectivy yet, until it has been tested and validated.
