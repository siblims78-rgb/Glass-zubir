# Glass ONN — security and testing notes

This is an inspectable Android TV prototype, not a certified app, and it has NOT yet been built or tested on a physical ONN device.

- Uses `INTERNET` only; no Accessibility, Contacts, Google sign-in, microphone, camera, Notification Listener or device location permissions.
- Weather and prayer data are fetched from two fixed HTTPS origins: `api.open-meteo.com` and `solat.my`.
- The user selects a prayer-time zone manually. Neither API is authenticated with a private token.
- Google Play Protect must stay on. If Play Protect blocks the APK, stop rather than bypassing it.
- Test as a normal TV app first; Projectivy remains the Home launcher and fallback.
- Android TV WebView feature support can vary by firmware; frosted blur may degrade gracefully to translucent panels.
- As with any application, do not put passwords or secrets in repository files or issue screenshots.
