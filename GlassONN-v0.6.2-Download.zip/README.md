# Glass ONN v0.6.0 — Prayer Countdown, Trakt Connect, Language & Netflix Picks

Incremental upgrade based on the existing Glass ONN v0.5.9 source. **This is an Android TV test app, not a replacement for Sony Home or Projectivy.** The application ID is `com.glassonn.home.v060`, so v0.5.9 can remain installed for comparison.

## Changes

1. **Prayer countdown across midnight**: today’s times continue from the existing solat.my daily endpoint. After Isyak, the launcher requests the **JAKIM-derived yearly schedule** for its selected zone and looks for **tomorrow’s Fajr/Subuh**. If tomorrow’s schedule is not available or the request fails, the UI says so rather than guessing the time. The countdown is shown in `HH:MM:SS`, updates each second, and uses the selected zone. Changing the zone clears cached tomorrow data. Check against official e-Solat JAKIM for anything important.
2. **Continue Watching / Trakt**: the Home screen now offers **Connect Trakt** directly when Glass ONN is not yet authorized. This is intentionally separate from the Trakt scrobbling connection inside Stremio. After personal OAuth Device Code authorization, the existing read-only Trakt `/sync/playback` integration can display playback progress if the account and API permissions allow. Stremio internal progress and Netflix viewing history are not available to this launcher without independent authorized access.
3. **Language**: **English default**, with **Bahasa Melayu** switch at the top of TV Settings. Translates the main launcher surfaces, dialog labels, and a range of supporting settings. A few legacy diagnostics and generated metadata labels may remain in the original source language; no movie titles are machine-translated. Language preference is held in the WebView's private local storage.
4. **Netflix Picks · Malaysia**: new optional Home shelf based on **TMDB `/discover/movie` and `/discover/tv`**, filtering with `watch_region=MY`, Netflix provider ID `8`, and `flatrate`. It requires a personal TMDB Read Access Token (or v3 API key). It is **not Netflix account recommendations, Netflix Top 10, or Netflix Continue Watching**. Actual availability can change; the Netflix app is opened via title search when the user selects a supported title. A clear **Connect TMDB** action appears until configured. Never share your token in ChatGPT or a public repository.
5. Original apps, wallpaper, weather FX, search, Next Play, D-pad navigation, layout editing and phone Companion remain in the existing codebase.

## Build in GitHub

1. Upload `GlassONN-v0.6.0-Download.zip` to the root of your `Glass-zubir` repo (select **Choose your files** and verify the file is listed before committing).
2. In your existing `.github/workflows/build-from-zip.yml`, change only the unzip line to:

   ```sh
   unzip -o -q GlassONN-v0.6.0-Download.zip
   ```

3. Commit, open GitHub Actions, and download the **GlassONN-debug-apk** artifact from the latest successful build. Unzip it and install `app-debug.apk` as a normal test app on the Sony or ONN device.

## Trakt setup

- The user's Stremio account showing **Trakt Scrobbling** does not authorize Glass ONN.
- Set up a personal Trakt API app at <https://developer.trakt.tv/> and use the TV's **Settings → Trakt** panel. Never place API credentials in the GitHub repo, phone Companion, or chat.
- Approve the code on the official verification page shown by Trakt. The launcher does not need your Trakt account password.
- Data availability depends on Trakt's current API permissions, recent scrobbling events, and whether that data was actually synchronized by Stremio. The application will not fabricate playback progress.

## Netflix setup

- Enter a personal TMDB read-only token using **Settings → Netflix Picks (TMDB)** on the TV. The token is stored privately on that device.
- If not connected, a clear Home prompt appears instead of fake Netflix titles. On successful retrieval, Netflix Malaysia catalogue titles appear in a scrollable shelf.
- The TV must have an internet connection. TMDB catalog listings do not certify that a particular title is playable on the user's Netflix plan, and an app search may require additional remote navigation.

## Testing performed

- `node --check` for JavaScript passed.
- Browser interaction passed on **1280×720, 1920×1080 and 1280×600**: English default / Malay switch, real Trakt authorization prompt, Netflix shelf with mocked TMDB results, remote-accessible settings, and Home vertical scrolling.
- Simulated **23:53 Malaysia time** with tomorrow’s valid schedule showed `Next prayer: Fajr tomorrow · 05:56:00`. Missing tomorrow data remained clearly marked unavailable.
- Android source was syntax-inspected, **but no APK build or actual Trakt/Netflix network authentication has been run for this version**. Treat this as beta source until GitHub Actions and Sony TV testing succeed.

## Security

The application does not declare itself as Android HOME, does not require Accessibility, and does not require bypassing Play Protect. Trakt tokens use Android Keystore encryption in the existing implementation. TMDB preferences and HTTP LAN companion access are local to the device. Use the Companion only on trusted Wi-Fi; never expose its port to the internet. Keep Sony Home/Projectivy installed as backup.


## v0.6.1 (8 Nov 2026) — TV test release
- D-pad settings navigation now includes text/password inputs; Android receives OK/Enter for keyboard input while editing.
- Unlimited pinned favourites in the horizontally scrollable Home dock.
- Individual Home visibility toggles for Trakt Continue Watching, manual Next Play, Movies, TV Shows, and Netflix Picks.
- Larger two-line next-prayer countdown including tomorrow's Subuh when next-day data is available.
- Customizable clock font, size, color and glow (stored locally on TV).
- New synthesized offline rain-drop and bird-call clips; old wind clip is no longer used.
- Separate test application ID v0.6.1 to avoid debug APK signing conflicts; earlier installation and preferences remain untouched.

This source ZIP is **not an APK**. Upload the ZIP to the project's GitHub repository and build it with the Android workflow. The full app requires an Android TV/ONN field test, especially Trakt IME/remote navigation and audio. Never post Trakt/TMDB tokens in the repository.
