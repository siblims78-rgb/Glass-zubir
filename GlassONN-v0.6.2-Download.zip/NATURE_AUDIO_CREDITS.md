# Glass ONN v0.6.2 nature audio credits

These are real unmodified field recordings, downloaded directly from Wikimedia Commons on first playback and cached in Android local app cache. No synthetic wind, thunder, birds, or drops are bundled.

* **Forest birds** — Barracuda1983, public domain: https://commons.wikimedia.org/wiki/File:Birds_forest.ogg
* **Water drops dripping** — ZooFari, CC BY-SA 3.0: https://commons.wikimedia.org/wiki/File:Water_drops_dripping.ogg
  License: https://creativecommons.org/licenses/by-sa/3.0/

Playback uses original recordings without edit or remix. Android may not be able to download first-time audio if Wikimedia is blocked; in this case there is no sound (never the old synthesized fallback). Sound volume is reduced, capped to 11 seconds, and stopped when leaving the launcher.
