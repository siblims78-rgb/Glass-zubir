# Security notes for Glass ONN v0.6.0

- Debug APK is for personal testing only. Keep Android Play Protect on and preserve Sony Home/Projectivy as backup. Never bypass an Android security warning.
- No Accessibility, VPN, AccessibilityService, root, overlay, package installer, or system-HOME override privileges are requested.
- **Trakt is opt-in and read-only**. TV-local OAuth Device Code registration requires the TV owner's personal Trakt API app. No account password is requested, and no Client ID, Client Secret, access/refresh token is hard-coded in source, GitHub, or the Companion app.
- Credentials and session tokens are encrypted with Android Keystore (AES-GCM). Local disconnect deletes encrypted data. Revoke the authorization separately on Trakt to invalidate server-side sessions.
- Trakt recommends PKCE with verified HTTPS App Links for distributed public apps; this personal device flow should not be represented as a hardened multi-user auth architecture. Do **not** copy another app's Trakt Client Secret or publish personal secrets.
- Phone Companion remains LAN-only HTTP, limited to a trusted home Wi-Fi network with pairing PIN. It does not expose any Trakt data/tokens or perform Trakt account setup.
- Trakt external HTTPS connections are restricted to `auth.trakt.tv` and `api.trakt.tv`. The app limits response size, uses connect/read timeouts, honors device-code polling intervals, and only retrieves user's authorized playback data.
- Cinemeta, weather, solat times, movie artwork and other online integrations require external HTTPS connectivity. Do not run this personal test APK on untrusted networks. Do not expose LAN HTTP port 8765 to the internet.
- If Trakt responds with forbidden, restricted, rate-limit or invalid token errors, no attempts should be made to bypass the access controls. The app will show an error and preserve the manual Next Play list.
