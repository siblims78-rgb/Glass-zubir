# Glass ONN v0.2 — Android TV WebView dashboard

## Apa yang berubah
- Galeri wallpaper **terbina dalam**: empat ilustrasi pemandangan offline 16:9; remote boleh memilih Automatik (30 saat) atau 1 gambar tetap. Tidak lagi memerlukan Android file picker.
- Panel glass kekal semasa wallpaper berubah.
- Tetapan lokasi asal: **Setapak / Kuala Lumpur**, zon solat **WLY01**; ada pilihan Gombak / Selangor (SGR01), Kuala Lumpur, Johor Bahru, Pulau Pinang.
- Pilihan wallpaper disimpan antara buka/tutup aplikasi.
- Remote Back boleh menutup menu Tetapan.
- Semua penemuan aplikasi dan fungsi membuka aplikasi asal v0.1 dikekalkan.

## Status
**Source projek sahaja, belum diuji pada ONN untuk v0.2.** GitHub Actions mungkin diperlukan untuk menghasilkan APK. Grafik wallpaper merupakan **ilustrasi pemandangan dijana secara asli**, bukan gambar fotografi. Import gambar peribadi belum disokong pada ONN tanpa pemilih fail.

## Privacy / keselamatan
Hanya permission Android INTERNET, tiada Accessibility, lokasi GPS, overlay, akaun, pemasangan aplikasi, microphone. Cuaca menggunakan Open-Meteo, solat menggunakan solat.my. Data solat perlu disemak melalui e-Solat JAKIM untuk kegunaan penting. Projectivy kekal sebagai launcher HOME.

## Cara membina menggunakan repo Glass-zubir
1. Upload ZIP ini sebagai `GlassONN-Upload.zip` di root repo, menggantikan fail ZIP v0.1 yang ada; workflow sedia ada mengekstrak nama tersebut.
2. Commit perubahan ke `main`; Actions -> Build Glass ONN APK berjalan. Jika ia tak bermula, pilih `Run workflow`.
3. Download artifact `GlassONN-debug-apk`, extract `.apk`, dan pasang untuk ujian.
4. Versi 0.2 menggunakan ID pakej berbeza `com.glassonn.home.v02` supaya boleh diuji **sebelah v0.1** walaupun debug signing key GitHub berubah. Jangan tetapkan sebagai HOME sehingga diuji.

## Binaan
- Java 17, Gradle 8.9, Android SDK 34, Android Gradle Plugin 8.6.1.
- WebView offline file asset untuk UI dan wallpaper; internet hanya untuk cuaca dan solat.
- Empat fail JPEG pemandangan berkualiti optimum untuk TV RAM 2GB.
