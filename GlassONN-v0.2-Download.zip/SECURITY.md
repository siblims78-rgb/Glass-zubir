# Glass ONN v0.2 — safety and test notes

Version 0.1 was installed and its app shortcuts were tested successfully by the project owner on an ONN 4K Android TV. Version 0.2 **has not yet been built or tested on the ONN device**.

- Permission: `INTERNET` only; no Accessibility, contacts, Google sign-in, microphone, camera, notification listener or device location.
- Weather and prayer data: fixed HTTPS origins `api.open-meteo.com` and `solat.my`; if unavailable, the UI should show placeholders rather than fabricate times.
- Prayer times are not guaranteed; verify with e-Solat JAKIM.
- Keep Google Play Protect active. If it blocks installation, do not bypass the warning.
- Test as a normal app; Projectivy is still the Home launcher. Version 0.2 has a distinct package ID from 0.1 to allow testing side-by-side.
- Embedded wallpapers are original illustrations, not photographs; no external wallpaper-image server is required.
- WebView backdrop blur may vary by ONN firmware; translucent panels remain as fallback.
- Never include passwords, private keys, access tokens or personal information in repository.
