package com.glassonn.home;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Locally-rendered TV launcher concept; no accessibility, notification or location permissions. */
public class MainActivity extends Activity {
    private static final int PICK_WALLPAPER = 201;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private WebView page;
    private final String[][] places = {
        {"Setapak / Kuala Lumpur", "WLY01", "3.205", "101.718"},
        {"Gombak / Selangor", "SGR01", "3.257", "101.702"},
        {"Kuala Lumpur", "WLY01", "3.139", "101.687"},
        {"Johor Bahru", "JHR02", "1.493", "103.742"},
        {"Pulau Pinang", "PNG01", "5.414", "100.329"}
    };

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
        page = new WebView(this);
        page.setBackgroundColor(0xff0b1224);
        page.getSettings().setJavaScriptEnabled(true);
        page.getSettings().setDomStorageEnabled(true);
        page.getSettings().setAllowFileAccess(true);
        page.getSettings().setAllowContentAccess(false);
        page.getSettings().setAllowFileAccessFromFileURLs(false);
        page.getSettings().setAllowUniversalAccessFromFileURLs(false);
        page.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"file".equalsIgnoreCase(request.getUrl().getScheme());
            }
        });
        page.addJavascriptInterface(new LocalBridge(), "Native");
        setContentView(page);
        page.loadUrl("file:///android_asset/index.html");
    }

    private void callJs(String code) { ui.post(() -> { if (page != null) page.evaluateJavascript(code, null); }); }

    private String localImage() {
        try {
            File f = new File(getFilesDir(), "wallpaper.jpg");
            if (!f.exists() || f.length() > 2_000_000L) return "";
            ByteArrayOutputStream data = new ByteArrayOutputStream();
            try (FileInputStream stream = new FileInputStream(f)) {
                byte[] chunk = new byte[8192]; int n;
                while ((n = stream.read(chunk)) != -1) data.write(chunk, 0, n);
            }
            return "data:image/jpeg;base64," + Base64.encodeToString(data.toByteArray(), Base64.NO_WRAP);
        } catch (Exception ignored) { return ""; }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_WALLPAPER || result != RESULT_OK || data == null || data.getData() == null) return;
        try (InputStream input = getContentResolver().openInputStream(data.getData())) {
            if (input == null) return;
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            // Large images are sampled when loaded to protect 2GB RAM devices.
            byte[] all; try (ByteArrayOutputStream b = new ByteArrayOutputStream()) {
                byte[] chunk = new byte[8192]; int n;
                while ((n = input.read(chunk)) > 0 && b.size() < 15_000_000) b.write(chunk, 0, n);
                all = b.toByteArray();
            }
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(all, 0, all.length, bounds);
            int sample = 1;
            while (bounds.outWidth / sample > 1920 || bounds.outHeight / sample > 1080) sample *= 2;
            BitmapFactory.Options decode = new BitmapFactory.Options(); decode.inSampleSize = sample;
            Bitmap bitmap = BitmapFactory.decodeByteArray(all, 0, all.length, decode);
            if (bitmap == null) return;
            File f = new File(getFilesDir(), "wallpaper.jpg");
            try (FileOutputStream out = new FileOutputStream(f)) { bitmap.compress(Bitmap.CompressFormat.JPEG, 78, out); }
            bitmap.recycle();
            callJs("window.receiveWallpaper(" + JSONObject.quote(localImage()) + ")");
        } catch (Exception ex) { Toast.makeText(this, "Wallpaper tidak dapat dibuka", Toast.LENGTH_SHORT).show(); }
    }

    private class LocalBridge {
        @JavascriptInterface public String getPlace() { return getPreferences(MODE_PRIVATE).getString("place", "0"); }
        @JavascriptInterface public void setPlace(String index) {
            try { int n = Integer.parseInt(index); if (n < 0 || n >= places.length) return;
                getPreferences(MODE_PRIVATE).edit().putString("place", ""+n).apply();
            } catch (Exception ignored) {}
        }
        @JavascriptInterface public String wallpaper() { return localImage(); }
        @JavascriptInterface public String getWallpaperMode() { return getPreferences(MODE_PRIVATE).getString("wallpaper_mode", "auto"); }
        @JavascriptInterface public void setWallpaperMode(String mode) {
            if (mode == null || !(mode.equals("auto") || mode.matches("[0-3]"))) return;
            getPreferences(MODE_PRIVATE).edit().putString("wallpaper_mode",mode).apply();
        }
        @JavascriptInterface public void pickWallpaper() {
            ui.post(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
                if (i.resolveActivity(getPackageManager()) != null) startActivityForResult(i, PICK_WALLPAPER);
                else Toast.makeText(MainActivity.this, "Guna galeri wallpaper dalam Tetapan", Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void clearWallpaper() {
            new File(getFilesDir(), "wallpaper.jpg").delete();
            callJs("window.receiveWallpaper('')");
        }
        @JavascriptInterface public String getApps() {
            JSONArray apps = new JSONArray();
            PackageManager manager = getPackageManager();
            Set<String> seen = new HashSet<>();
            List<ResolveInfo> all = new ArrayList<>();
            Intent tv = new Intent(Intent.ACTION_MAIN); tv.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
            all.addAll(manager.queryIntentActivities(tv, 0));
            Intent phone = new Intent(Intent.ACTION_MAIN); phone.addCategory(Intent.CATEGORY_LAUNCHER);
            all.addAll(manager.queryIntentActivities(phone, 0));
            Collections.sort(all, Comparator.comparing(x -> String.valueOf(x.loadLabel(manager)).toLowerCase()));
            for (ResolveInfo info : all) {
                if (info.activityInfo == null) continue;
                String pkg = info.activityInfo.packageName;
                if (getPackageName().equals(pkg) || !seen.add(pkg)) continue;
                try {
                    JSONObject j = new JSONObject();
                    j.put("name", String.valueOf(info.loadLabel(manager))); j.put("pkg", pkg);
                    Drawable icon = info.loadIcon(manager);
                    if (icon != null) {
                        Bitmap bitmap = Bitmap.createBitmap(76,76,Bitmap.Config.ARGB_8888);
                        Canvas c = new Canvas(bitmap); icon.setBounds(0,0,76,76); icon.draw(c);
                        ByteArrayOutputStream b = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 90, b);
                        bitmap.recycle();
                        j.put("icon", "data:image/png;base64,"+Base64.encodeToString(b.toByteArray(), Base64.NO_WRAP));
                    }
                    apps.put(j);
                } catch (Exception ignored) {}
            }
            return apps.toString();
        }
        @JavascriptInterface public void openApp(String pkg) {
            if (pkg == null || pkg.length() > 180 || !pkg.matches("[A-Za-z0-9_.]+")) return;
            ui.post(() -> {
                Intent i = getPackageManager().getLeanbackLaunchIntentForPackage(pkg);
                if (i == null) i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i != null) { try { startActivity(i); } catch (Exception ignored) {} }
                else Toast.makeText(MainActivity.this, "Aplikasi tidak dijumpai", Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void fetch(String kind) {
            if (!"weather".equals(kind) && !"prayer".equals(kind)) return;
            new Thread(() -> {
                try {
                    int n = Integer.parseInt(getPlace()); n = Math.max(0,Math.min(n,places.length-1));
                    String[] p = places[n];
                    String address = "weather".equals(kind)
                        ? "https://api.open-meteo.com/v1/forecast?latitude="+p[2]+"&longitude="+p[3]+"&current=temperature_2m,relative_humidity_2m,weather_code&timezone=Asia%2FKuala_Lumpur"
                        : "https://solat.my/api/daily/"+p[1];
                    HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
                    connection.setConnectTimeout(8500); connection.setReadTimeout(8500);
                    connection.setRequestProperty("User-Agent", "GlassONN/0.2 (personal Android TV dashboard)");
                    if (connection.getResponseCode() != 200) throw new Exception("HTTP " + connection.getResponseCode());
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    try (InputStream stream = new BufferedInputStream(connection.getInputStream())) {
                        byte[] buffer = new byte[4096]; int count;
                        while ((count = stream.read(buffer)) > 0 && out.size() < 160_000) out.write(buffer,0,count);
                    }
                    connection.disconnect();
                    String data = out.toString("UTF-8");
                    // Only data from two fixed HTTPS APIs. Response is passed as a string, never executed.
                    callJs("window.onNativeData("+JSONObject.quote(kind)+","+JSONObject.quote(data)+")");
                } catch (Exception ex) {
                    callJs("window.onNativeData("+JSONObject.quote(kind)+",'')");
                }
            }).start();
        }
    }

    @Override public void onBackPressed() { callJs("if(window.hideSettings)window.hideSettings();"); }
    @Override protected void onDestroy() { if (page != null) page.destroy(); super.onDestroy(); }
}
