# Security notes

- Debug APK is for testing only. Preserve Play Protect. Never bypass a block to install it.
- No root, no ADB background service, no Accessibility or overlay role.
- Optional phone companion is a LAN-only HTTP server that stops on activity pause. It listens on port 8765 and requires a six-digit pairing PIN plus an in-memory random token. Five invalid pairing PINs cause a two-minute lockout. The pairing PIN is shown on the TV only. Do not publish/forward TCP port 8765 to the internet.
- Local HTTP is **not encrypted**. Treat the phone companion as an early beta: use trusted Wi-Fi, not guest/public/shared networks, and avoid exposing TMDB tokens on an untrusted LAN. No account passwords should ever be supplied.
- External HTTPS fetches are hardcoded to Open-Meteo, solat.my, Wikimedia Commons and (with an optional user-provided token) TMDB. Images in the TV use Wikimedia HTTPS and TMDB HTTPS hosts. User content is displayed as text (not executed as scripts).
- All app list is accessed by an authenticated companion session. App launch requests are validated against launchable packages on TV. Favorite list capped at eight.
- If phones can't reach TV due to network isolation, do NOT weaken router security or disable protective features; continue using remote control.
