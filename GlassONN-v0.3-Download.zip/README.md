# Glass ONN v0.3 — preview source for ONN 4K Android TV 14

**Status:** Source code has been authored and browser-preview tested. **Not yet compiled as Android APK or tested on an actual ONN device.** Keep v0.2 and Projectivy installed as backups. Debug APKs should be tested only after Google Play Protect checks; never override a security warning.

## 5 targets

1. **Online wallpapers:** `Sumber wallpaper → Wikimedia Commons` uses the public MediaWiki API to request landscape photographs (thumbnail widths ~1600 px) and cycles them; creator/license text is displayed when available. The existing four wallpapers remain offline fallback. **Reddit is NOT integrated** because its official Data API requires approval and OAuth; scraping is intentionally not used.
2. **Weather animation:** lightweight rain, subtle lightning glow, or sun-ray CSS over the full Home screen, chosen from **current Open-Meteo WMO weather code**. Optional toggle (default ON). After at least ~70 s of inactivity, the effect lasts ~3.8 s no more than every 5 min. Effect does not run when the TV is off/asleep or when another app is foreground; it's an idle **launcher** effect, not a system screensaver/overlay. Use `Uji animasi cuaca` in Settings for a preview.
3. **All Apps:** a focusable TV app grid. Open apps and choose up to 8 Home favorites with remote. No usage of Accessibility or all-package visibility permissions.
4. **Trending:** browse current week's movie and series metadata/posters from TMDB. Requires an **optional TMDB API Read Access Token** (or v3 API key) entered locally through Companion. Shows title, rating and synopsis, **not video playback**. Adult-flagged entries excluded. TMDB attribution is included. No credential is embedded in the APK or source.
5. **Phone Companion (beta):** ONN app runs a small **local HTTP server** on TCP port `8765` while Glass ONN is in the foreground. Open `Settings → Companion` on TV to see its IP URL and 6-digit pairing code. In Chrome on a phone on the *same trusted Wi-Fi*, open that URL, enter PIN, then change location, wallpaper source/mode, weather effects and Home favorites. No phone APK is needed: use a browser shortcut. Access requires pairing and an ephemeral session token. **HTTP is not end-to-end encrypted**, so do not use on public/untrusted/shared Wi-Fi, and never enter personal passwords. Optional TMDB read-only credentials may traverse the local Wi-Fi unencrypted, so use a trusted home network. If the TV sleeps/another app opens, the local control server stops. Unpair by leaving app/relaunching.

## Limitations & known issues

- Photo feed from Wikimedia may fail due to internet/API restrictions; offline wallpaper is the fallback. It is not guaranteed that every Commons photo has licensing information fully captured; check original file page for reuse/redistribution.
- **Reddit wallpapers** would require official approval + OAuth and separate integration. No bypass, scraping or embedded account tokens included.
- **TMDB** needs legitimate API credentials; do not paste them into GitHub or chat. Trending metadata is not availability/playback in Stremio or Netflix.
- **Android TV standby:** app animations cannot show when screen is powered off, when other apps are foreground, or as a universal Android screensaver without a separate system integration.
- Some modern phone browsers block insecure local HTTP pages or client isolation/VPN prevents LAN connections. Use same trusted Wi-Fi; don't change Google Play Protect settings to make it work.
- Test remote navigation and performance on ONN 2GB RAM before making this a Home launcher. This app does **not** register the HOME intent.

## Build with existing `Glass-zubir` GitHub Actions

1. Upload source ZIP to repo root as `GlassONN-v0.3-Download.zip`, keeping v0.2 ZIP as backup.
2. Edit `.github/workflows/build-from-zip.yml` line `unzip -o -q GlassONN-v0.2-Download.zip` → `unzip -o -q GlassONN-v0.3-Download.zip`.
3. Commit. GitHub Actions `Build Glass ONN APK` will compile `:app:assembleDebug`. Download artifact ZIP on a successful run. **Do not assume a successful Gradle build proves each feature works at runtime.**
4. Keep original v0.2 and Projectivy in place while testing. Package ID `com.glassonn.home.v03` is independent of v0.2.

## Build settings

Gradle 8.9; Android Gradle Plugin 8.6.1; compile/target SDK 34; Java 17; min SDK 26. App requests `android.permission.INTERNET` only. No GPS, microphone, camera, overlay, notification access, Accessibility, or package installer permissions.
