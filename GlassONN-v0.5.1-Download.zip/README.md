# Glass ONN v0.5.1 • TV controls and discovery improvements

## Changed
- Clock/prayer cards now use adjustable opacity (8–60%, default 20%) and background blur (0–18px, default 9). Controls on TV and phone companion.
- Larger, consistently sized launcher icons with lighter card borders, focus ring and horizontal scrolling.
- Trending posters: press OK to route to Netflix if TMDB watch-provider metadata for Malaysia (MY) explicitly lists Netflix subscription streaming and TMDB token is configured. Otherwise open Stremio search. If metadata comes from Apple/TVMaze (no matching TMDB ID) availability cannot be verified; use Stremio search. Neither app guarantees a title-specific opening or autoplay, and availability may change.
- Weather canvas animation (rain droplets and streaks, soft cloud layers, sun haze, gentle localized storm lightning). Runs in short 4.3-second bursts while app is visible. Capped near 26 fps with canvas density limited to 1.2.
- All Apps, Hide/Restore, Display Cards, dynamic wallpaper, Setapak WLY01, and phone companion retained.

## Safety, usage and limits
- Android TV experimental **app**, not a HOME replacement. Keep Projectivy / Sony HOME as backup. No root or Accessibility request; Play Protect remains enabled.
- Uses Android system WebView; no bundled browser library.
- TMDB token optional and stored locally in app preferences, not in GitHub; when absent all poster items route to Stremio search because streaming availability is unknown. TMDB/JustWatch provider data may lag and **does not include Netflix title IDs**. Netflix opens its search or home, not guaranteed title page.
- On some Stremio Android TV versions the documented search deep link may not pre-populate. Manual search may be necessary.
- Weather FX are artistic visualizations, not an actual outdoor recording and not shown when TV sleeps or is powered off. On old TVs blur may be unavailable or expensive.
- Companion HTTP LAN control uses pairing PIN, and remains **unencrypted**: only use on trusted home Wi-Fi; do not forward TCP port 8765 outside your LAN. Token never goes in public URL.
- Online imagery / charts require working TV connectivity. Offline wallpaper fallback remains.
- Test source / Chromium UI first, then GitHub Actions debug APK. Device behavior not guaranteed until tested.


## v0.5.1 incremental changes
- TV D-pad slider focus now includes input elements; large -/+ buttons operate opacity/blur via OK even on devices without input range focus support.
- Explicit `⚡ Kilat` demo. One localized gentle lightning pulse; no full-screen flashing/strobing. Only storm weather triggers this automatically.
- Android TV 16:9 app banners when provided; fallback wide 16:9 tiles containing undistorted square icons.
- Trending `Lihat semua` opens full viewport, vertical scrolling 6-column poster grid; All/Movies/Series filter and Refresh. Feeds capped to a few dozen items; US chart data not Malaysia Netflix availability.
- Hold OK (~650 ms) on Home/All Apps entry for context menu. Open, Home favorite, Hide/Restore, App Info, Uninstall (Android system confirmation, unavailable for some system apps). Browser long right-click also opens context.
- App uninstallation is never silent. No dangerous permissions or developer privilege.
- APK compile and Sony TV behavior still require GitHub Actions and on-device tests.

- v0.5.1 has its own Android application ID `com.glassonn.home.v051` because ephemeral GitHub debug signing keys may prevent in-place updates of prior builds. It can be installed alongside v0.5. Local preferences are not automatically migrated.
